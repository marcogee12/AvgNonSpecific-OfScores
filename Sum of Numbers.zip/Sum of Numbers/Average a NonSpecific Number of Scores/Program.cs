using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average_a_NonSpecific_Number_of_Scores
{
    class Program
    {
        static void Main(string[] args)
        {
            string response = "done";
            double avg = 0;
            int count = 0;
            double average = avg / count;
            
            Console.WriteLine("Here you will calculate test score average");
            do
            {
                Console.WriteLine("Please enter test score: ");
                double a = Convert.ToDouble(Console.ReadLine());
                if ((a < 0) || (a > 100))
                {
                    Console.WriteLine("Score entered is out of range. Please enter a score ranging between 0 - 100");
                    --count;
                }
                else
                {
                    count++;
                    avg = avg + a;
                    average = avg / count;
                }
                Console.WriteLine("Please type in 'done' below if you are done inputing test scores. If not click enter to continue.");
                response = Console.ReadLine();

            }
            while (response != "done");
            Console.WriteLine($"Test score average is:{average}%");
            if ((average >= 90) && (average <= 100))
            {
                Console.WriteLine("Grade: A");
            }
            else if ((average >= 80) && (average <= 89))
            {
                Console.WriteLine("Grade: B");
            }
            else if ((average >= 70) && (average <= 79))
            {
                Console.WriteLine("Grade: C");
            }
            else if ((average >= 60) && (average <= 69))
            {
                Console.WriteLine("Grade: D");
            }
            else if ((average >= 0) && (average <= 59))
            {
                Console.WriteLine("Grade: F");
            }
            Console.ReadKey();
        }
    }
}
