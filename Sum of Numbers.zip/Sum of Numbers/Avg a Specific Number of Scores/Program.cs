using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Avg_a_Specific_Number_of_Scores
{
    class Program
    {
        static void Main(string[] args)
        {
            double avg = 0;
            Console.WriteLine("Here you will calculate test score average");
            Console.WriteLine("How many test scores do you want to average?");
            double t = Convert.ToDouble(Console.ReadLine());
            for (int i = 0; i < t; i++)
            {
                Console.WriteLine("Please enter test score: ");
                double a = Convert.ToDouble(Console.ReadLine());
                if ((a < 0) || (a > 100))
                {
                    Console.WriteLine("Score entered is out of range. Please enter a score ranging between 0 - 100");
                    --i;
                }
                else
                {
                    avg = avg + a / t;
                }
            }
            Console.WriteLine($"Test Score Average:{avg}%"); 
            Console.ReadKey();
        }
    }
}
