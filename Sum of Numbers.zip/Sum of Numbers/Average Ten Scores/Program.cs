using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Average_Ten_Scores
{
    class Program
    {
        static void Main(string[] args)
        {
            double avg = 0;
            Console.WriteLine("Here you will calculate test score average");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Please enter test score: ");
                double a = Convert.ToDouble(Console.ReadLine());
                if ((a < 0) || (a > 100))
                {
                    Console.WriteLine("Score entered is out of range. Please enter a score ranging between 0 - 100");
                    --i;
                }
                else
                {
                    avg = avg + a / 10;
                }
            }
            Console.WriteLine($"Test Score Average:{avg}%");
            Console.ReadKey();
        }
    }
}
